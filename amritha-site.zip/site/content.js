// All site content lives here. Edit this file and push; the site updates itself.
// Sections with empty lists (notes, publications) stay hidden until you add items.
window.SITE = {
  name: "Amritha Pradeep",
  tagline: "M.Sc. Mathematics student at IIT Madras",
  about: "I am pursuing an M.Sc. in Mathematics at IIT Madras, with a foundation in pure mathematics and a growing interest in coding theory and cryptography. I have been introduced to mathematical research through guided reading projects and advanced mathematical camps, and I am looking to engage more deeply with research in coding theory and cryptography.",
  interests: ["Number Theory", "Coding Theory", "Cryptography"],
  education: [
    { title: "M.Sc. Mathematics", place: "Indian Institute of Technology Madras, Chennai", years: "2025–2027", note: "CGPA 8.92 (first and second semesters combined)" },
    { title: "B.Sc. Mathematics", place: "Stella Maris College, Chennai", years: "2022–2025", note: "CGPA 9.8. First rank." },
    { title: "Class XII and Class X", place: "Delhi Private School, Sharjah", years: "", note: "Class XII: 97.6%. Class X: 96%." }
  ],
  research: [
    { title: "Reading project under Dr. Ananthnarayan Hariharan", place: "IIT Bombay", years: "December 2025", note: "Studied fields and field extensions, then introductory coding theory: basic error-correcting codes, Hamming distance and related concepts." },
    { title: "IMSc Summer Research Program, under Prof. Sanoli Gun", place: "Institute of Mathematical Sciences, Chennai", years: "May–June 2026", note: "Guided reading of Serre's A Course in Arithmetic, covering introductory algebraic number theory including Legendre symbols and p-adic integers." }
  ],
  programs: [
    "MTTS Level-O Summer Camp (2024)",
    "MTTS Level-I Summer Camp (2025)",
    "Mentor at OFCM by MTTS Trust (2024, 2025)",
    "Madhava Mathematics Nurture Camp, Chennai Mathematical Institute (2024)",
    "Madhava Mathematics Nurture Camp, IIT Bombay (2025)",
    "Vigyan Vidhushi Program 2025, TIFR Mumbai"
  ],
  courses: [
    { group: "NPTEL", items: ["Advanced Engineering Mathematics, IIT Kharagpur (Course Topper)", "Basic Calculus, IIT Madras", "The Joy of Computing using Python, IIT Ropar"] },
    { group: "Coursera", items: ["Introduction to Mathematical Thinking, Stanford University", "Linear Algebra: Orthogonality and Diagonalization, Johns Hopkins University"] }
  ],
  skills: "Python, LaTeX",
  languages: "English, Tamil, Hindi, Malayalam, Arabic",
  notes: [],         // e.g. { title: "Notes on p-adic integers", url: "notes/padic.pdf", date: "2026" }
  publications: [],  // e.g. { title: "...", venue: "...", year: "...", url: "..." }
  contact: { email: "aspradeep369@gmail.com", location: "Chennai, India", linkedin: "https://linkedin.com/in/amritha-pradeep-b5b014377" },
  cv: "assets/CV_Amritha.pdf"
};
