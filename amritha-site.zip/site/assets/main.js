(function(){
const S=window.SITE,$=id=>document.getElementById(id);
function h(tag,attrs,...kids){const e=document.createElement(tag);for(const k in attrs||{})e.setAttribute(k,attrs[k]);kids.flat().forEach(c=>e.append(c));return e}
const item=o=>h("div",{class:"item"},h("p",{},h("strong",{},o.title)),h("p",{class:"meta"},[o.place,o.years].filter(Boolean).join(", ")),o.note?h("p",{},o.note):"");
const link=(href,text)=>h("a",{href,rel:"noopener"},text);
document.title=S.name+" · Mathematics, IIT Madras";$("name").textContent=S.name;$("tagline").textContent=S.tagline;
const secs=[
["about","About",()=>h("p",{},S.about)],
["education","Education",()=>S.education.map(item)],
["research","Research interests",()=>[h("ul",{class:"tags"},S.interests.map(i=>h("li",{},i))),h("h3",{},"Reading projects"),...S.research.map(item)]],
["programs","Programs and camps",()=>h("ul",{class:"plain"},S.programs.map(p=>h("li",{},p)))],
["courses","Courses and skills",()=>[...S.courses.map(g=>h("div",{class:"item"},h("p",{},h("strong",{},g.group)),h("ul",{class:"plain"},g.items.map(i=>h("li",{},i))))),h("p",{},h("strong",{},"Technical skills: "),S.skills),h("p",{},h("strong",{},"Languages: "),S.languages)]],
["notes","Mathematical notes",()=>S.notes.map(n=>h("p",{},n.url?link(n.url,n.title):n.title,n.date?" ("+n.date+")":"")),S.notes.length],
["publications","Publications",()=>S.publications.map(p=>h("p",{},p.url?link(p.url,p.title):p.title,[p.venue,p.year].filter(Boolean).length?", "+[p.venue,p.year].filter(Boolean).join(", "):"")),S.publications.length],
["cv","CV",()=>h("p",{},h("a",{class:"btn",href:S.cv,download:""},"Download CV (PDF)"))],
["contact","Contact",()=>[h("p",{},"Email: ",link("mailto:"+S.contact.email,S.contact.email)),h("p",{},"LinkedIn: ",link(S.contact.linkedin,"Amritha Pradeep")),h("p",{},S.contact.location)]]
];
const nav=$("nav"),root=$("sections");
secs.forEach(([id,title,build,show])=>{if(show===0)return;
nav.append(h("li",{},h("a",{href:"#"+id},title.split(" ")[0])));
root.append(h("section",{class:"s",id},h("h2",{},title),build()))});
$("foot").textContent="© "+new Date().getFullYear()+" "+S.name;
// theme
const btn=$("theme"),root_=document.documentElement;
function sync(){const d=root_.dataset.theme==="dark";btn.textContent=d?"Light":"Dark";btn.setAttribute("aria-label","Switch to "+(d?"light":"dark")+" mode")}
sync();btn.onclick=()=>{root_.dataset.theme=root_.dataset.theme==="dark"?"light":"dark";try{localStorage.setItem("theme",root_.dataset.theme)}catch(e){}sync()};
// Hamming distance demo
const x=[1,0,1,1,0,0,1],y=[1,1,1,0,0,1,1],bits=$("bits"),dist=$("dist");
function draw(){bits.replaceChildren();[["x",x],["y",y]].forEach(([n,w])=>{const r=h("div",{class:"row"},h("b",{},n));
w.forEach((v,i)=>{const o=n==="x"?y:x,b=h("button",{type:"button",class:"bit"+(v!==o[i]?" diff":""),"aria-label":`${n} bit ${i+1}: ${v}`},String(v));
b.onclick=()=>{w[i]^=1;draw()};r.append(b)});bits.append(r)});
const d=x.filter((v,i)=>v!==y[i]).length,t=`d(x,y)=${d}`;
if(window.katex){try{dist.innerHTML=katex.renderToString(t)}catch(e){dist.textContent=t}}else dist.textContent=t}
draw();addEventListener("load",draw);
})();
