# Amritha Pradeep: academic website

A static, dependency-free site (HTML, CSS, JavaScript). No build step, so it deploys exactly as written.

## Update content
Edit `content.js` (all text) and replace `assets/CV_Amritha.pdf` with your newest CV (keep the file name). Add entries to `notes` or `publications` and those sections appear automatically.

## Run locally
```
python3 -m http.server 8000
```
Open http://localhost:8000.

## Deploy (GitHub Pages)
1. Create a new empty repository on GitHub (e.g. `amritha-pradeep.github.io` for a root URL, or any name).
2. In this folder: `git init -b main && git add . && git commit -m "Initial site"`
3. `git remote add origin https://github.com/<your-username>/<repo>.git && git push -u origin main`
4. On GitHub: Settings → Pages → Source: **GitHub Actions**.
5. Every push to `main` now redeploys via `.github/workflows/deploy.yml`.
